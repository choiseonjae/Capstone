package com.example.capstone.Common;

import com.example.capstone.Model.User;

public class Common {
    public static User currentUser;
}
